#include <iostream>
#include "Sequence.hpp"
Sequence::Sequence(){
  first = NULL;
  last = NULL;
}
void Sequence::insert(double x){

}
void Sequence::clear(){

}
int Sequence::size(){
  return 0;
}
double Sequence::stdDeviation(){
  return 0;
}
